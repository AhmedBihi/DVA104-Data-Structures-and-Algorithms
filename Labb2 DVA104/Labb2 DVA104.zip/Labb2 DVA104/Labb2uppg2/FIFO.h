/***********************************************************
* Lista & K�, Labb 2 uppgift 2                             *
* ADT L�nkad Lista (FIFO.h)                                *
*                                                          *
* Datastrukturer, algoritmer och programkonstruktion,DVA104*
* Ahmed Bihi                                               *
* 19920613                                                 *
* abi14002                                                 *
***********************************************************/

#ifndef FIFO_H_INCLUDED
#define FIFO_H_INCLUDED
#include "list.h"

typedef List Queue;

Queue *queueCreate();

/*Precondition: noOfNodesInList(myQueue) returnerar falskt
  Postcondition: Det f�rsta elementet i k�n �r borttagen
  Return:
  */
void dequeue(Queue *myQueue);


/*Postcondition: Data har lagts in i en nod sist i k�n*/
void enqueue(Queue *myQueue, int data);


/*Precondition: noOfNodesInList(myQueue) returner falskt
  Skriver ut k�n*/
void printQueue(Queue *myQueue);


/*Precondition: noOfNodesInList(myQueue) returnerar falskt
  Returnerar det f�rsta elementet i k�n */
int frontelement(Queue *q);


/*Returnerar om k�n �r tom, annars return 0*/
int queueSize(Queue *myQueue);


/*Precondition: noOfNodesInList(myQueue) returner falskt
  Postcondition: elementet i k�n �r frigjorda*/
void emptyQueue(Queue *myQueue);


/*Precondition: noOfNodesInList(myQueue) returner falskt
  Postcondition: k�n �r frigjord*/
void destroyQueue(Queue *myQueue);

#endif // FIFO_H_INCLUDED
